import { useState } from 'react'
import ListItem from "./ListItem.jsx";

function DynamicList() {
    const [element, setElement] = useState("");
    const [elements, setElements] = useState(0);
    const [elementsList, setElementsList] = useState([]);

    function addElement() {
        setElements(elements + 1);
        const newItem = {key: elements, text: element};
        setElementsList(elementsList.concat([newItem]));
    }

    function deleteItem(key) {
        const updatedList = elementsList.filter(item => key !== item.key);
        setElementsList(updatedList);
    }

    function remElement() {
        setElementsList(elementsList.slice(0,-1))
        setElements(elements - 1);
    }

    return (
        <div className="card">
            <ul>
                {
                    elementsList.map((item, index) => {
                        return (
                            <ListItem key={index}
                                itemKey={index}
                                item={item}
                                deleteItem={deleteItem}
                        />)
                    })
                }
            </ul>
            <input type="text"
                   onChange={(e) => setElement(e.target.value)}/>
            <button onClick={addElement}>
                Add element to list
            </button>
            <button onClick={remElement}>
                Remove last element from list
            </button>
        </div>
    );
}

export default DynamicList
