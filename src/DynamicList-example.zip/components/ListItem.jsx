import React from 'react'

function ListItem(props) {
    return (
        <li key={props.itemKey}>{props.item.text}
            &emsp; <button onClick={()=>props.deleteItem(props.itemKey)}>Delete</button>
        </li>
    )
}

export default ListItem;